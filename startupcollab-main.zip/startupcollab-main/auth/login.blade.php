@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="text-center text-white">Login</h2>
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
    <p class="text-center mt-3">
        Don't have an account? <a href="{{ route('signup') }}">Sign up</a>
    </p>
</div>
@endsection