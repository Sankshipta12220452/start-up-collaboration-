@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="text-center text-white">Sign Up</h2>
    <form method="POST" action="{{ route('signup') }}">
        @csrf
        <input type="text" name="name" placeholder="Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" class="btn btn-primary w-100">Sign Up</button>
    </form>
    <p class="text-center mt-3">
        Already have an account? <a href="{{ route('login') }}">Login</a>
    </p>
</div>
@endsection