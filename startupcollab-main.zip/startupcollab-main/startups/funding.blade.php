<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Funding Opportunities - Startup Hub</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #e0e5ec;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .navbar {
      background-color: #343a40;
    }

    .navbar-brand, .nav-link {
      color: white;
    }

    .navbar-nav .nav-item .nav-link:hover {
      color: #ffc107;
    }

    .container {
      max-width: 1200px;
    }

    h2 {
      margin-top: 50px;
      text-align: center;
      color: #343a40;
    }

    .funding-container {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 50px;
    }

    .funding-card {
      width: 80%;
      max-width: 600px;
      border-radius: 10px;
      color: #fff;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      text-align: center;
      position: relative;
      overflow: hidden;
      transition: background-color 0.5s ease;
    }

    .card-img-top {
      width: 100%;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    }

    .card-body {
      padding: 20px;
    }

    .card-title {
      font-size: 1.5rem;
      font-weight: bold;
    }

    .card-text {
      margin-bottom: 10px;
    }

    .btn-info {
      border-radius: 5px;
      padding: 10px 20px;
      transition: background-color 0.3s;
      color: white;
      border: none;
    }

    .btn-info:hover {
      filter: brightness(90%);
    }

    .arrow-btn {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      background-color: rgba(0, 0, 0, 0.5);
      color: white;
      border: none;
      font-size: 2rem;
      padding: 10px;
      cursor: pointer;
    }

    .arrow-btn-left {
      left: 10px;
    }

    .arrow-btn-right {
      right: 10px;
    }
  </style>
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light">
  <div class="container">
    <a class="navbar-brand" href="#">Startup Hub</a>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="/hmms">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="/startups">Startups</a></li>
        <li class="nav-item"><a class="nav-link" href="/events">Events</a></li>
        <li class="nav-item"><a class="nav-link" href="/funding">Funding</a></li>
        <li class="nav-item"><a class="nav-link" href="/contact">Contact Us</a></li>
        <li class="nav-item"><a class="nav-link" href="/investors">Investors</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Funding Opportunity Section -->
<section id="funding-opportunity" class="my-5">
  <div class="container">
    <h2>Available Funding Opportunities</h2>
    <div class="funding-container">
      <div id="fundingCard" class="funding-card" style="background-color: #007bff;">
        <img id="fundingImage" src="https://via.placeholder.com/1500x800" class="card-img-top" alt="Funding Opportunity Image">
        <div class="card-body">
          <h5 id="fundingTitle" class="card-title">Venture Capital Investment Fund</h5>
          <p id="fundingDescription" class="card-text">This funding opportunity offers venture capital to innovative startups in the tech sector. Eligible companies can receive up to $5 million in equity funding.</p>
          <p id="fundingEligibility"><strong>Eligibility Criteria:</strong> Startups in AI, SaaS, and Cloud computing. Must have been operating for at least 1 year.</p>
          <p id="fundingAmount"><strong>Funding Amount:</strong> Up to $5 million (equity investment)</p>
          <p id="fundingDeadline"><strong>Deadline:</strong> June 30, 2025</p>
        </div>
        <div class="card-footer bg-transparent">
          <a id="fundingLink" href="/funding/venture-capital" class="btn btn-info">Learn More</a>
        </div>
      </div>

      <button class="arrow-btn arrow-btn-left" onclick="changeFunding(-1)">&#8592;</button>
      <button class="arrow-btn arrow-btn-right" onclick="changeFunding(1)">&#8594;</button>
    </div>
  </div>
</section>

<script>
  const fundingData = [
    {
      image: "https://via.placeholder.com/1500x800?text=Venture+Capital",
      title: "Venture Capital Investment Fund",
      description: "This funding opportunity offers venture capital to innovative startups in the tech sector. Eligible companies can receive up to $5 million in equity funding.",
      eligibility: "Startups in AI, SaaS, and Cloud computing. Must have been operating for at least 1 year.",
      amount: "Up to $5 million (equity investment)",
      deadline: "June 30, 2025",
      link: "/funding/venture-capital",
      bgColor: "#007bff"
    },
    {
      image: "https://via.placeholder.com/1500x800?text=Greentech+Grant",
      title: "Government Grant for GreenTech",
      description: "The GreenTech Grant Program offers funding for projects that promote sustainable energy solutions and technologies.",
      eligibility: "Focused on renewable energy, sustainability, or energy-efficient technologies. Businesses must be U.S.-based.",
      amount: "Up to $2 million (grant)",
      deadline: "August 15, 2025",
      link: "/funding/greentech-grant",
      bgColor: "#28a745"
    },
    {
      image: "https://via.placeholder.com/1500x800?text=Accelerator+Fund",
      title: "Startup Accelerator Fund",
      description: "This fund offers both mentorship and financial support to early-stage startups in any industry looking for growth opportunities.",
      eligibility: "Early-stage startups. Must have a working prototype or MVP.",
      amount: "$100,000 (equity investment)",
      deadline: "July 1, 2025",
      link: "/funding/accelerator-fund",
      bgColor: "#17a2b8"
    }
  ];

  let currentFundingIndex = 0;

  function changeFunding(direction) {
    currentFundingIndex = (currentFundingIndex + direction + fundingData.length) % fundingData.length;
    const current = fundingData[currentFundingIndex];

    // Update content
    document.getElementById("fundingImage").src = current.image;
    document.getElementById("fundingTitle").innerText = current.title;
    document.getElementById("fundingDescription").innerText = current.description;
    document.getElementById("fundingEligibility").innerHTML = `<strong>Eligibility Criteria:</strong> ${current.eligibility}`;
    document.getElementById("fundingAmount").innerHTML = `<strong>Funding Amount:</strong> ${current.amount}`;
    document.getElementById("fundingDeadline").innerHTML = `<strong>Deadline:</strong> ${current.deadline}`;
    document.getElementById("fundingLink").href = current.link;

    // Update background color
    document.getElementById("fundingCard").style.backgroundColor = current.bgColor;

    // Update button color
    const btn = document.getElementById("fundingLink");
    btn.style.backgroundColor = current.bgColor;
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
