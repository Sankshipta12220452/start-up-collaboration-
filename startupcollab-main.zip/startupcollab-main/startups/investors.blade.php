<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Investor Network | Empowering Innovation with StartupCollab</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-image: url('https://www.example.com/new-background.jpg'); /* Replace with actual image URL */
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
    }

    .navbar-custom {
      background-color: rgba(0, 0, 0, 0.75);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(8px);
    }

    .logo {
      font-size: 26px;
      font-weight: bold;
      color: #00bcd4;
    }

    .nav-links a {
      margin-right: 20px;
      font-weight: 500;
      color: #ffffff;
      text-decoration: none;
    }

    .nav-links a:hover {
      color: #00bcd4;
    }

    .header-banner {
      text-align: center;
      padding: 60px 20px;
      background-color: rgba(0, 0, 0, 0.5);
      border-radius: 10px;
      margin: 40px auto;
      width: 80%;
    }

    .header-banner h1 {
      font-size: 48px;
      font-weight: bold;
      color: #ffc107;
    }

    .main-content {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      padding: 40px 20px;
    }

    .card {
      background: rgba(0, 0, 0, 0.7);
      padding: 30px;
      border-radius: 15px;
      text-align: center;
      width: 300px;
      margin: 20px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5);
      color: #ffffff;
      transition: transform 0.3s ease-in-out;
    }

    .card:hover {
      transform: translateY(-10px);
    }

    .card img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      margin-bottom: 15px;
      border: 4px solid #00bcd4;
    }

    .card h2 {
      color: #00e676;
      font-size: 22px;
      margin-bottom: 10px;
    }

    .contact-button {
      display: block;
      width: 250px;
      margin: 40px auto;
      padding: 15px;
      font-size: 18px;
      text-align: center;
      background-color: #25D366;
      color: white;
      border-radius: 50px;
      text-decoration: none;
      font-weight: bold;
    }

    .contact-button:hover {
      background-color: #1ebe57;
    }

    .footer {
      text-align: center;
      padding: 20px;
      background-color: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(10px);
      color: #f8f9fa;
    }
  </style>
</head>
<body>

<!-- Navigation Bar -->
<div class="navbar-custom">
  <div class="logo">StartupCollab</div>
  <div class="nav-links">
    <a href="{{ route('startups') }}">Startups</a>
    <a href="{{ route('investors') }}">Investors</a>
    <a href="{{ route('funding') }}">Funding</a>
    <a href="{{ route('events') }}">Events</a>
    <a href="{{ route('contact') }}">Contact</a>
  </div>
</div>

<!-- Header Banner -->
<div class="header-banner">
  <h1>Investor Network | Empowering Innovation with StartupCollab</h1>
  <p>Connecting visionary investors with groundbreaking startups</p>
</div>

<!-- Investors Showcase -->
<div class="main-content">
<div class="card">
  <img src="https://nursinginstitutegoa.org/wp-content/uploads/2016/01/tutor-8.jpg" alt="Investor">
  <h2>📈 John Doe</h2>
  <p>Venture Capitalist specializing in fintech and AI-driven startups.</p>
</div>
<div class="card">
  <img src="https://eoculus-images.aiany.org/wp-content/uploads/2017/05/Jane-2016a-Photo-credit-is-Tanya-Braganti.jpg" alt="Investor">
  <h2>💡 Jane Smith</h2>
  <p>Angel Investor focusing on sustainability and eco-friendly ventures.</p>
</div>
<div class="card">
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCUJ80cmux1PEz2IxhUKZ6MqZz7ylGuLuO5g&s" alt="Michael Lee">
  <h2>💼 Michael Lee</h2>
  <p>Private Equity Investor passionate about health-tech innovations.</p>
</div>

<div class="card">
  <img src="https://www.wilsoncenter.org/sites/default/files/styles/480x480/public/media/uploads/images/emma%20brown%20headshot.jpg" alt="Emma Brown">
  <h2>🌱 Emma Brown</h2>
  <p>Impact Investor driving change in clean energy and environmental tech.</p>
</div>
</div>

<!-- Contact Us Button -->
<a href="https://wa.me/919912769416?text=Hello!%20I'm%20interested%20in%20StartupCollab." class="contact-button" target="_blank">
  Contact Us on WhatsApp
</a>

<!-- Footer -->
<div class="footer">
  <p>&copy; 2025 StartupCollab | Empowering Innovation</p>
</div>

</body>
</html>
