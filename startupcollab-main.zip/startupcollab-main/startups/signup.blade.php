<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Signup - StartupColab</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center" style="height: 100vh;">

  <div class="card p-4 shadow" style="width: 100%; max-width: 400px;">
    <h2 class="mb-4 text-center">Join StartupColab</h2>
    
    <form onsubmit="event.preventDefault(); window.location.href='/signin';">
      <input type="text" class="form-control mb-3" placeholder="Name" required>
      <input type="email" class="form-control mb-3" placeholder="Email" required>
      <input type="password" class="form-control mb-3" placeholder="Password" required>
      <button type="submit" class="btn btn-primary w-100">Sign Up</button>
    </form>

    <div class="text-center mt-3">
      <p>Already have an account? <a href="/signin">Sign in here</a></p>
    </div>
  </div>

</body>
</html>
