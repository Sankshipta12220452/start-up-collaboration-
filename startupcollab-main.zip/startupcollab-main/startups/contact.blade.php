<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Startup Collaboration Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('https://digitalleadership.com/wp-content/uploads/2021/12/Corporate-Startup-collaboration-scaled-1.webp');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: #f0f0f0;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
        }

        .navbar-custom {
            background-color: rgba(0, 0, 0, 0.6);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #00bcd4;
        }

        .nav-links a {
            margin-right: 25px;
            font-weight: 500;
            color: #ffffff;
            text-decoration: none;
        }

        .nav-links a:hover {
            color: #00bcd4;
        }

        .sign-in-btn {
            background-color: #00bcd4;
            color: #ffffff;
            border: none;
            padding: 8px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .sign-in-btn:hover {
            background-color: #0097a7;
        }

        .contact-form-container {
            max-width: 600px;
            margin: 50px auto;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 10px;
        }

        .form-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-header h2 {
            color: #ffc107;
        }

        .form-group label {
            color: #f0f0f0;
        }

        .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .form-group textarea {
            height: 150px;
        }

        .btn-submit {
            background-color: #00bcd4;
            color: #fff;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }

        .btn-submit:hover {
            background-color: #0097a7;
        }

        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<div class="navbar-custom">
    <div class="logo">StartupCollab</div>
    <div class="nav-links">
     <a href="{{ route('dashboard') }}">Dashboard</a>
        <a href="{{ route('startups') }}">Startups</a>
        <a href="{{ route('investors') }}">Investors</a>
        <a href="{{ route('funding') }}">Funding</a>
        <a href="{{ route('events') }}">Events</a>
        <a href="{{ route('contact') }}">Contact Us</a>
    </div>
    <a href="{{ route('signin') }}">
        
        <button class="sign-in-btn">Sign In</button>
    </a>
</div>

<!-- Contact Form -->
<div class="contact-form-container">
    <div class="form-header">
        <h2>Contact Us</h2>
        <p>We'd love to hear from you! Please fill out the form below:</p>
    </div>

    <!-- Display Success/Error Messages -->
    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    <!-- Contact Form -->
    <form action="{{ route('submit.contact') }}" method="POST" id="contactForm">
        @csrf
        <div class="form-group">
            <label for="name">Your Name</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Enter your name" required>
        </div>
        <div class="form-group">
            <label for="email">Your Email</label>
            <input type="email" name="email" id="email" class="form-control" placeholder="Enter your email" required>
        </div>
        <div class="form-group">
            <label for="message">Your Message</label>
            <textarea name="message" id="message" class="form-control" placeholder="Write your message here" required></textarea>
        </div>
        <button type="submit" class="btn-submit">Send Message</button>
    </form>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2025 StartupCollab | Empowering Innovation</p>
</div>

<!-- Success Popup -->
<script>
    // Detect if a success message is present in the session
    @if(session('success'))
        alert("Thanks for contacting us! We will get back to you shortly.");
    @endif
</script>

</body>
</html>
