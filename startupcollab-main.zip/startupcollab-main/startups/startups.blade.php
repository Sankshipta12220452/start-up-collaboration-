<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Startup Hub Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    body {
      background-color: #e6f2ff;
    }
    .navbar {
      background-color: #ffffff;
      box-shadow: 0px 2px 5px rgba(0,0,0,0.1);
    }
    .card-img-top {
      height: 200px;
      object-fit: cover;
    }
    .container {
      max-width: 1200px;
    }
    h2 {
      margin-top: 50px;
      margin-bottom: 30px;
      color: #004080;
      font-weight: bold;
      text-align: center;
    }
    .btn-primary {
      background-color: #007bff;
      border: none;
    }
    .btn-info {
      background-color: #17a2b8;
      border: none;
    }
    .card {
      margin-bottom: 30px;
      transition: transform 0.3s ease;
    }
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0px 8px 15px rgba(0,0,0,0.1);
    }
    footer {
      background-color: #004080;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: 50px;
    }
    .card-body {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .d-grid {
      text-align: center;
    }
    .card-title {
      text-align: center;
    }
    .card-body p {
      text-align: left;
    }
    .d-flex {
      display: flex;
      justify-content: space-between;
    }
    .d-flex .btn {
      width: 48%;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light">
  <div class="container">
    <a class="navbar-brand fw-bold text-primary" href="#">StartupCollab</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="/hmms">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="/startups">Startups</a></li>
        <li class="nav-item"><a class="nav-link" href="/events">Events</a></li>
        <li class="nav-item"><a class="nav-link" href="/funding">Funding</a></li>
        <li class="nav-item"><a class="nav-link" href="/investors">Investors</a></li>
        <li class="nav-item"><a class="nav-link" href="/contact">Contact Us</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Startups Section -->
<section id="startups" class="my-5">
  <div class="container">
    <h2>Our Startups</h2>
    <div class="row g-4 justify-content-center">
      <!-- Startup 1 -->
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <img src="https://images.unsplash.com/photo-1556155092-8707de31f9c4?auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="Tech Innovators Image">
          <div class="card-body">
            <h5 class="card-title text-center">Tech Innovators</h5>
            <p class="card-text">Revolutionizing the way companies manage data with AI-driven tools.</p>
            <p><strong>Industry:</strong> SaaS</p>
            <p><strong>Stage:</strong> Seed Funding</p>
            <p><strong>Location:</strong> San Francisco, USA</p>
            <div class="d-grid gap-2">
              <a href="http://techinnovators.com" class="btn btn-primary" target="_blank">Visit Website</a>
              <a href="/startups/tech-innovators" class="btn btn-info">Learn More</a>
            </div>
          </div>
        </div>
      </div>

      
      <!-- Startup 3 -->
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <<img src="https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="GreenTech Solutions Image">
          <div class="card-body">
            <h5 class="card-title text-center">GreenTech Solutions</h5>
            <p class="card-text">Innovative green energy solutions for sustainable development.</p>
            <p><strong>Industry:</strong> GreenTech</p>
            <p><strong>Stage:</strong> Growth Stage</p>
            <p><strong>Location:</strong> Berlin, Germany</p>
            <div class="d-grid gap-2">
              <a href="http://greentechsolutions.com" class="btn btn-primary" target="_blank">Visit Website</a>
              <a href="/startups/greentech-solutions" class="btn btn-info">Learn More</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Startup 4 -->
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <img src="https://images.unsplash.com/photo-1596495577886-d920f1fb7238?auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="EduSpark Image">
          <div class="card-body">
            <h5 class="card-title text-center">EduSpark</h5>
            <p class="card-text">A leading ed-tech startup revolutionizing the way students learn online.</p>
            <p><strong>Industry:</strong> EdTech</p>
            <p><strong>Stage:</strong> Series B</p>
            <p><strong>Location:</strong> London, UK</p>
            <div class="d-grid gap-2">
              <a href="http://eduspark.com" class="btn btn-primary" target="_blank">Visit Website</a>
              <a href="/startups/eduspark" class="btn btn-info">Learn More</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Startup 5 -->
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <img src="https://images.unsplash.com/photo-1521791055366-0d553872125f?auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="AgroLink Image">
          <div class="card-body">
            <h5 class="card-title text-center">AgroLink</h5>
            <p class="card-text">Digitizing the agricultural supply chain with smart logistics.</p>
            <p><strong>Industry:</strong> AgriTech</p>
            <p><strong>Stage:</strong> Pre-Series A</p>
            <p><strong>Location:</strong> Pune, India</p>
            <div class="d-grid gap-2">
              <a href="http://agrolink.com" class="btn btn-primary" target="_blank">Visit Website</a>
              <a href="/startups/agrolink" class="btn btn-info">Learn More</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Startup 6 -->
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <img src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=800&q=80" class="card-img-top" alt="FinBuddy Image">
          <div class="card-body">
            <h5 class="card-title text-center">FinBuddy</h5>
            <p class="card-text">Your financial buddy for budgeting, saving, and investing smarter.</p>
            <p><strong>Industry:</strong> FinTech</p>
            <p><strong>Stage:</strong> Series C</p>
            <p><strong>Location:</strong> Mumbai, India</p>
            <div class="d-grid gap-2">
              <a href="http://finbuddy.com" class="btn btn-primary" target="_blank">Visit Website</a>
              <a href="/startups/finbuddy" class="btn btn-info">Learn More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer -->
<footer>
  <p>&copy; 2025 StartupCollab. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
