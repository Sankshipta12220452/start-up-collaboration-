<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Events - Startup Hub</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #e9f7ef;
    }
    .navbar {
      margin-bottom: 30px;
    }
    .card-img-top {
      height: 200px;
      object-fit: cover;
    }
    .container {
      max-width: 1200px;
    }
    h2 {
      margin-top: 50px;
      margin-bottom: 30px;
    }
    .btn {
      margin-top: 10px;
    }
  </style>
</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#">StartupColab</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="/hmms">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/startups">Startups</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/events">Events</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/funding">Funding</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/contact">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/investors">Investors</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Events Section -->
<section id="events" class="my-5">
  <div class="container">
    <h2 class="text-center mb-4">Upcoming Events</h2>
    <div class="row">
      
      <!-- Event 1 -->
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="https://images.pexels.com/photos/3184432/pexels-photo-3184432.jpeg" class="card-img-top" alt="Startup Pitch Day">
          <div class="card-body">
            <h5 class="card-title">Startup Pitch Day</h5>
            <p class="card-text">Present your ideas to top investors and industry leaders.</p>
            <p><strong>Date:</strong> May 15, 2025</p>
            <p><strong>Location:</strong> Silicon Valley, USA</p>
            <a href="https://www.startup.com" class="btn btn-info" target="_blank">Learn More</a>
          </div>
        </div>
      </div>

      <!-- Event 2 -->
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="https://images.pexels.com/photos/1617816/pexels-photo-1617816.jpeg" class="card-img-top" alt="Green Energy Innovation Conference">
          <div class="card-body">
            <h5 class="card-title">Green Energy Innovation Conference</h5>
            <p class="card-text">Explore the future of sustainable energy with top innovators.</p>
            <p><strong>Date:</strong> June 10, 2025</p>
            <p><strong>Location:</strong> Berlin, Germany</p>
            <a href="https://www.greenenergyconference.com" class="btn btn-info" target="_blank">Learn More</a>
          </div>
        </div>
      </div>

      <!-- Event 3 -->
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="https://images.unsplash.com/photo-1556740738-b6a63e27c4df" class="card-img-top" alt="Healthcare Innovation Summit">
          <div class="card-body">
            <h5 class="card-title">Healthcare Innovation Summit</h5>
            <p class="card-text">Discover the latest healthcare technologies and investment opportunities.</p>
            <p><strong>Date:</strong> July 22, 2025</p>
            <p><strong>Location:</strong> New York, USA</p>
            <a href="https://www.healthcareinnovationsummit.com" class="btn btn-info" target="_blank">Learn More</a>
          </div>
        </div>
      </div>

      <!-- Event 4 -->
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="https://images.pexels.com/photos/1181240/pexels-photo-1181240.jpeg" class="card-img-top" alt="Tech Conference 2025">
          <div class="card-body">
            <h5 class="card-title">Tech Conference 2025</h5>
            <p class="card-text">Join industry leaders to discuss the future of technology.</p>
            <p><strong>Date:</strong> August 10, 2025</p>
            <p><strong>Location:</strong> San Francisco, USA</p>
            <a href="https://www.techconference2025.com" class="btn btn-info" target="_blank">Learn More</a>
          </div>
        </div>
      </div>

      <!-- Event 5 -->
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="https://images.pexels.com/photos/6802199/pexels-photo-6802199.jpeg" class="card-img-top" alt="AI for Good Summit">
          <div class="card-body">
            <h5 class="card-title">AI for Good Summit</h5>
            <p class="card-text">Explore how artificial intelligence can improve our world.</p>
            <p><strong>Date:</strong> September 5, 2025</p>
            <p><strong>Location:</strong> London, UK</p>
            <a href="https://www.aiforgood.org" class="btn btn-info" target="_blank">Learn More</a>
          </div>
        </div>
      </div>

      <!-- Event 6 -->
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="https://images.pexels.com/photos/3184437/pexels-photo-3184437.jpeg" class="card-img-top" alt="Blockchain Expo">
          <div class="card-body">
            <h5 class="card-title">Blockchain Expo</h5>
            <p class="card-text">Dive into the world of blockchain and cryptocurrencies.</p>
            <p><strong>Date:</strong> October 15, 2025</p>
            <p><strong>Location:</strong> Dubai, UAE</p>
            <a href="https://www.blockchainexpo.com" class="btn btn-info" target="_blank">Learn More</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
