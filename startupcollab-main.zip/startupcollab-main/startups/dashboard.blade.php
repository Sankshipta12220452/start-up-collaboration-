<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Collaboration Platform</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-image: url('https://digitalleadership.com/wp-content/uploads/2021/12/Corporate-Startup-collaboration-scaled-1.webp');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      color: #f0f0f0;
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
    }

    .navbar-custom {
      background-color: rgba(0, 0, 0, 0.6);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }

    .logo {
      font-size: 24px;
      font-weight: bold;
      color: #00bcd4;
    }

    .nav-links a {
      margin-right: 25px;
      font-weight: 500;
      color: #ffffff;
      text-decoration: none;
    }

    .nav-links a:hover {
      color: #00bcd4;
    }

    .sign-in-btn {
      background-color: #00bcd4;
      color: #ffffff;
      border: none;
      padding: 8px 15px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
    }

    .sign-in-btn:hover {
      background-color: #0097a7;
    }

    .header-banner {
      text-align: center;
      padding: 60px 20px 30px 20px;
      background-color: rgba(0, 0, 0, 0.5);
      border-radius: 10px;
      margin: 30px auto;
      width: 80%;
    }

    .header-banner h1 {
      font-size: 48px;
      font-weight: bold;
      color: #ffc107;
    }

    .header-banner p {
      font-size: 20px;
      color: #e0e0e0;
    }

    .main-content {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      padding: 40px 20px;
    }

    .card {
      background: rgba(0, 0, 0, 0.6);
      padding: 25px;
      border-radius: 10px;
      text-align: center;
      width: 300px;
      margin: 20px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.5);
      color: #ffffff;
    }

    .card h2 {
      color: #00e676;
      margin-bottom: 15px;
    }

    .card p {
      color: #e0e0e0;
    }

    .card a {
      display: inline-block;
      margin-top: 15px;
      color: #00bcd4;
      text-decoration: none;
      font-weight: bold;
    }

    .card a:hover {
      text-decoration: underline;
    }

    .footer {
      text-align: center;
      padding: 20px;
      background-color: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(10px);
      color: #f0f0f0;
    }
  </style>
</head>
<body>

  <!-- Navigation Bar -->
  <div class="navbar-custom">
    <div class="logo">StartupCollab</div>
    <div class="nav-links">
      <a href="{{ route('startups') }}">Startups</a>
      <a href="{{ route('investors') }}">Investors</a>
      <a href="{{ route('funding') }}">Funding</a>
      <a href="{{ route('events') }}">Events</a>
      <a href="{{ route('contact') }}">Contact Us</a> <!-- ✅ Added Contact Us -->
    </div>
    <a href="{{ route('signin') }}">
      <button class="sign-in-btn">Sign In</button>
    </a>
  </div>

  <!-- Header Banner -->
  <div class="header-banner">
    <h1>Startup Collaboration Platform</h1>
    <p>Connecting Founders & Investors for Innovation & Growth</p>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="card">
      <h2>🚀 Startup Profiles</h2>
      <p>Showcase your startup and gain visibility.</p>
      <a href="{{ route('startups') }}">Explore Startups</a>
    </div>
    <div class="card">
      <h2>💼 Investor Connections</h2>
      <p>Connect with potential investors.</p>
      <a href="{{ route('investors') }}">Find Investors</a>
    </div>
    <div class="card">
      <h2>💰 Funding Opportunities</h2>
      <p>Find Seed, Series A, and Growth funding.</p>
      <a href="{{ route('funding') }}">Browse Funding</a>
    </div>
  </div>

  <!-- Footer -->
  <div class="footer">
    <p>&copy; 2025 StartupCollab | Empowering Innovation</p>
  </div>

</body>
</html>
