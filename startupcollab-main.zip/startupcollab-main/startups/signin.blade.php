<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Access StartupColab</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to bottom, #cce7ff, #e3f2fd);
      font-family: 'Segoe UI', sans-serif;
      color: white;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .container {
      display: flex;
      width: 90%;
      max-width: 1100px;
      height: 80vh;
    }

    .left-side {
      flex: 1;
      position: relative;
      overflow: hidden;
      height: 100%;
      max-width: 40%;
    }

    .left-side img {
      height: 100%;
      width: 100%;
      object-fit: cover;
      position: absolute;
      transition: opacity 1s ease-in-out;
    }

    .right-side {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .card {
      border-radius: 10px;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(12px);
      color: black;
      box-shadow: 0 4px 8px rgba(0,0,0,0.15);
      width: 80%;
      max-width: 400px;
      padding: 20px;
    }

    .btn-primary {
      background-color: #007bff;
      border-color: #007bff;
      color: white;
    }

    .form-control {
      background: rgba(255, 255, 255, 0.7);
      color: black;
      border: none;
      border-radius: 5px;
    }

    .sign-up-link {
      text-align: center;
      margin-top: 15px;
      font-size: 16px;
    }

    .sign-up-link a {
      color: #007bff;
      text-decoration: none;
      font-weight: 600;
    }

    .sign-up-link a:hover {
      text-decoration: underline;
    }

    #error-message {
      color: #f8d7da;
      background-color: rgba(248, 215, 218, 0.8);
      padding: 10px;
      text-align: center;
      border-radius: 5px;
      display: none;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="left-side">
    <img id="image1" src="https://images.unsplash.com/photo-1556740738-b6a63e27c4df" alt="Image 1" style="opacity: 1;">
    <img id="image2" src="https://images.pexels.com/photos/1181240/pexels-photo-1181240.jpeg" alt="Image 2" style="opacity: 0;">
  </div>

  <div class="right-side">
    <div class="card">
      <h1 class="heading text-center">Access StartupColab</h1>
      <div id="error-message">Invalid name or password</div>
      <form id="signin-form">
        <input type="text" class="form-control mb-3" id="name" placeholder="Name" required>
        <input type="password" class="form-control mb-3" id="password" placeholder="Password" required>
        <button type="submit" class="btn btn-primary w-100">Sign In</button>
      </form>
      <div class="sign-up-link">
        <p>Don't have an account? <a href="/signup">Join StartupColab</a> now!</p>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.getElementById('signin-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevents page refresh

    var name = document.getElementById("name").value;
    var password = document.getElementById("password").value;

    if (name === "lokesh" && password === "1234") {
      window.location.href = "/hmms"; // Redirecting to the correct Laravel route
    } else {
      document.getElementById("error-message").style.display = "block";
    }
  });

  let currentImageIndex = 1;
  const images = [document.getElementById("image1"), document.getElementById("image2")];

  setInterval(() => {
    images[currentImageIndex].style.opacity = 0;
    currentImageIndex = (currentImageIndex + 1) % images.length;
    images[currentImageIndex].style.opacity = 1;
  }, 2000);
</script>

</body>
</html>