<?php

use Illuminate\Support\Facades\Route;


Route::view('/startups/contact', 'startups.contact')->name('startups.contact');
Route::view('/startups/dashboard', 'startups.dashboard')->name('startups.dashboard');
Route::view('/startups/events', 'startups.events')->name('startups.events');
Route::view('/startups/funding', 'startups.funding')->name('startups.funding');
Route::view('/startups/investors', 'startups.investors')->name('startups.investors');
Route::view('/startups/signin', 'startups.signin')->name('startups.signin');
Route::view('/startups/signup', 'startups.signup')->name('startups.signup');
Route::view('/startups', 'startups.startups')->name('startups.index');
